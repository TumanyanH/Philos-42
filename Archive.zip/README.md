Philos-42
